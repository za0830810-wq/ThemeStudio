package com.themestudio.app

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var preview: PreviewView
    private lateinit var themeRow: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var fontSpinner: Spinner
    private lateinit var depthSwitch: Switch

    private var fontNames: List<String> = emptyList()
    private var busy = false

    private val accent = 0xFF4DA3FF.toInt()
    private val muted = 0xFFA6ADBB.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
    }

    // ------------------------------------------------------------------
    // بناء الواجهة
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun sectionTitle(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 17f
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, dp(22), 0, dp(8))
        return t
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(muted)
        t.setPadding(0, dp(10), 0, dp(2))
        return t
    }

    private fun primaryButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        val bg = GradientDrawable()
        bg.setColor(accent)
        bg.cornerRadius = dp(14).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }

    private fun softButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        val bg = GradientDrawable()
        bg.setColor(0xFF272B36.toInt())
        bg.cornerRadius = dp(14).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toggle(text: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = text
        s.isChecked = checked
        s.setTextColor(Color.WHITE)
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        return s
    }

    private fun seek(min: Int, max: Int, value: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(this)
        sb.layoutDirection = View.LAYOUT_DIRECTION_LTR
        sb.max = max - min
        sb.progress = (value - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress + min)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        return sb
    }

    private fun spinner(items: List<String>, selected: Int, onSelect: (Int) -> Unit): Spinner {
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(selected)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onSelect(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL
        scroll.setBackgroundColor(0xFF0F1117.toInt())

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(32))
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val title = TextView(this)
        title.text = "استوديو الثيمات"
        title.textSize = 24f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        // المعاينة
        val size = ImageImport.screenSize(this)
        val pw = (resources.displayMetrics.widthPixels * 0.6f).toInt()
        val ph = (pw * size.second.toFloat() / size.first.toFloat()).toInt()
        preview = PreviewView(this, prefs)
        val plp = LinearLayout.LayoutParams(pw, ph)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = dp(14)
        root.addView(preview, plp)

        // الثيمات
        root.addView(sectionTitle("الثيمات"))
        val themeScroll = HorizontalScrollView(this)
        themeScroll.isHorizontalScrollBarEnabled = false
        themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        themeScroll.addView(themeRow)
        root.addView(themeScroll)
        buildThemeChips()

        // الصورة والذكاء الاصطناعي
        root.addView(sectionTitle("صورتك والذكاء الاصطناعي"))
        root.addView(softButton("اختيار صورة من المعرض") { pickPhoto() })
        depthSwitch = toggle("الساعة خلف الشكل في الصورة", prefs.depth) { on -> onDepthToggled(on) }
        root.addView(depthSwitch)
        statusText = TextView(this)
        statusText.textSize = 13f
        statusText.setTextColor(muted)
        statusText.text = "الذكاء الاصطناعي يعمل داخل هاتفك بدون إنترنت."
        root.addView(statusText)

        // الساعة
        root.addView(sectionTitle("الساعة"))
        root.addView(label("الشكل"))
        root.addView(
            spinner(listOf("سطر واحد  09:25", "سطران عموديان"), prefs.clockStyle) { pos ->
                if (pos != prefs.clockStyle) {
                    prefs.clockStyle = pos
                    preview.refresh()
                }
            }
        )
        root.addView(toggle("نظام 24 ساعة", prefs.use24h) { v -> prefs.use24h = v; preview.refresh() })
        root.addView(toggle("أرقام عربية ٠١٢٣", prefs.arabicDigits) { v -> prefs.arabicDigits = v; preview.refresh() })
        root.addView(toggle("إظهار التاريخ", prefs.showDate) { v -> prefs.showDate = v; preview.refresh() })
        root.addView(toggle("تدرج في اللون", prefs.fade) { v -> prefs.fade = v; preview.refresh() })

        root.addView(label("حجم الساعة"))
        root.addView(seek(20, 100, prefs.clockSizePct) { v -> prefs.clockSizePct = v; preview.refresh() })
        root.addView(label("الموضع (أعلى ← أسفل)"))
        root.addView(seek(0, 100, prefs.clockYPct) { v -> prefs.clockYPct = v; preview.refresh() })
        root.addView(label("الشفافية"))
        root.addView(seek(30, 255, prefs.clockOpacity) { v -> prefs.clockOpacity = v; preview.refresh() })

        root.addView(label("اللون"))
        root.addView(buildColorRow())

        // الخطوط
        root.addView(sectionTitle("الخطوط"))
        fontSpinner = Spinner(this)
        root.addView(fontSpinner)
        refreshFonts()
        root.addView(softButton("إضافة خط (TTF / OTF / TTC / WOFF)") { pickFonts() })
        root.addView(softButton("حذف الخط المحدد") { deleteSelectedFont() })
        val fontHint = TextView(this)
        fontHint.text = "يمكنك إضافة أي عدد من الخطوط في أي وقت، وتبقى محفوظة في التطبيق."
        fontHint.textSize = 12f
        fontHint.setTextColor(muted)
        root.addView(fontHint)

        // التعيين
        root.addView(sectionTitle("التطبيق على الهاتف"))
        root.addView(primaryButton("تعيين كخلفية حية (الرئيسية والقفل)") { applyWallpaper() })
        val applyHint = TextView(this)
        applyHint.text = "بعد فتح المعاينة اضغط «تعيين» ثم اختر الشاشة الرئيسية وشاشة القفل. " +
            "ساعة النظام الأصلية تبقى ظاهرة على القفل؛ اختر لها أبسط نمط من إعدادات الهاتف."
        applyHint.textSize = 12f
        applyHint.setTextColor(muted)
        root.addView(applyHint)

        setContentView(scroll)
    }

    private fun buildColorRow(): View {
        val colors = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFFFFD54F.toInt(), 0xFFFF8A65.toInt(), 0xFFF48FB1.toInt(),
            0xFFEF5350.toInt(), 0xFF81C784.toInt(), 0xFF80DEEA.toInt(), 0xFF64B5F6.toInt(),
            0xFFB39DDB.toInt(), 0xFFD4AF37.toInt(), 0xFF111111.toInt()
        )
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (col in colors) {
            val dot = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(dp(2), 0x66FFFFFF)
            dot.background = g
            dot.setOnClickListener {
                prefs.clockColor = col
                preview.refresh()
            }
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(5), dp(6), dp(5), dp(6))
            row.addView(dot, lp)
        }
        hs.addView(row)
        return hs
    }

    private fun buildThemeChips() {
        themeRow.removeAllViews()
        for ((i, t) in Themes.all.withIndex()) {
            val selected = i == prefs.themeIndex
            val chip = TextView(this)
            chip.text = t.name
            chip.setTextColor(Color.WHITE)
            chip.textSize = 13f
            chip.gravity = Gravity.CENTER
            chip.setPadding(dp(16), dp(14), dp(16), dp(14))
            val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(t.c1, t.c2, t.c3))
            g.cornerRadius = dp(14).toFloat()
            g.setStroke(if (selected) dp(3) else dp(1), if (selected) Color.WHITE else 0x55FFFFFF)
            chip.background = g
            chip.setOnClickListener { selectTheme(i) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(4), dp(2), dp(4), dp(2))
            themeRow.addView(chip, lp)
        }
    }

    private fun selectTheme(i: Int) {
        prefs.themeIndex = i
        prefs.touch()
        buildThemeChips()
        preview.reload()
        if (i == Themes.photoIndex && !AssetLoader.bgFile(this).exists()) {
            pickPhoto()
        }
    }

    // ------------------------------------------------------------------
    // الصورة والذكاء الاصطناعي
    // ------------------------------------------------------------------

    private fun setStatus(msg: String) {
        statusText.text = msg
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun pickPhoto() {
        if (busy) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_PHOTO)
        } catch (e: Exception) {
            toast("تعذر فتح المعرض")
        }
    }

    private fun importPhoto(uri: Uri) {
        busy = true
        setStatus("جاري تجهيز الصورة…")
        val app = applicationContext
        Thread {
            val ok = try {
                ImageImport.importPhoto(app, uri)
            } catch (t: Throwable) {
                false
            }
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (!ok) {
                    setStatus("تعذر قراءة هذه الصورة، جرّب صورة أخرى.")
                } else {
                    prefs.themeIndex = Themes.photoIndex
                    prefs.touch()
                    buildThemeChips()
                    preview.reload()
                    if (prefs.depth) {
                        runDepth()
                    } else {
                        setStatus("تم تعيين الصورة.")
                    }
                }
            }
        }.start()
    }

    private fun onDepthToggled(on: Boolean) {
        prefs.depth = on
        if (on && AssetLoader.bgFile(this).exists() && !AssetLoader.fgFile(this).exists()) {
            runDepth()
        } else {
            prefs.touch()
            preview.reload()
        }
    }

    private fun runDepth() {
        if (busy) return
        val bgFile = AssetLoader.bgFile(this)
        if (!bgFile.exists()) {
            setStatus("اختر صورة أولاً.")
            return
        }
        busy = true
        setStatus("جاري تحليل الصورة بالذكاء الاصطناعي… قد يستغرق بضع ثوانٍ.")
        val app = applicationContext
        val fgFile = AssetLoader.fgFile(this)
        Thread {
            var error: String? = null
            try {
                val bmp = BitmapFactory.decodeFile(bgFile.absolutePath)
                    ?: throw IllegalStateException("تعذر قراءة الصورة")
                val cut = DepthEngine.cutout(app, bmp)
                FileOutputStream(fgFile).use { cut.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (t: Throwable) {
                fgFile.delete()
                error = t.message ?: "فشل تحليل الصورة"
            }
            val failure = error
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (failure == null) {
                    prefs.depth = true
                    prefs.touch()
                    preview.reload()
                    setStatus("تم ✓ الساعة الآن خلف الشكل. يمكنك تحريكها بشريط الموضع.")
                } else {
                    prefs.depth = false
                    prefs.touch()
                    depthSwitch.isChecked = false
                    preview.reload()
                    setStatus("تعذر الفصل: $failure")
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------
    // الخطوط
    // ------------------------------------------------------------------

    private fun refreshFonts() {
        fontNames = FontStore.list(this)
        if (prefs.fontName.isNotEmpty() && !fontNames.contains(prefs.fontName)) {
            prefs.fontName = ""
        }
        val items = listOf("الخط الافتراضي") + fontNames
        fontSpinner.onItemSelectedListener = null
        fontSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        val idx = fontNames.indexOf(prefs.fontName)
        fontSpinner.setSelection(if (idx >= 0) idx + 1 else 0)
        fontSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val name = if (position == 0) "" else (fontNames.getOrNull(position - 1) ?: "")
                if (name != prefs.fontName) {
                    prefs.fontName = name
                    preview.reload()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun pickFonts() {
        if (busy) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(i, REQ_FONT)
        } catch (e: Exception) {
            toast("تعذر فتح مدير الملفات")
        }
    }

    private fun importFonts(data: Intent) {
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val single = data.data
            if (single != null) uris.add(single)
        }
        if (uris.isEmpty()) return
        busy = true
        setStatus("جاري إضافة الخطوط…")
        val app = applicationContext
        Thread {
            var lastOk: String? = null
            var okCount = 0
            val errors = ArrayList<String>()
            for (u in uris) {
                val r = FontStore.importFont(app, u)
                if (r.name != null) {
                    lastOk = r.name
                    okCount++
                } else if (r.error != null) {
                    errors.add(r.error)
                }
            }
            val selected = lastOk
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (selected != null) {
                    prefs.fontName = selected
                    prefs.touch()
                }
                refreshFonts()
                preview.reload()
                val sb = StringBuilder()
                if (okCount > 0) sb.append("تمت إضافة $okCount خط. ")
                if (errors.isNotEmpty()) sb.append(errors.joinToString("\n"))
                setStatus(sb.toString().trim())
            }
        }.start()
    }

    private fun deleteSelectedFont() {
        val name = prefs.fontName
        if (name.isEmpty()) {
            toast("اختر خطاً مضافاً أولاً")
            return
        }
        FontStore.delete(this, name)
        prefs.fontName = ""
        prefs.touch()
        refreshFonts()
        preview.reload()
    }

    // ------------------------------------------------------------------
    // تعيين الخلفية الحية
    // ------------------------------------------------------------------

    private fun applyWallpaper() {
        val comp = ComponentName(this, ClockWallpaperService::class.java)
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
            startActivity(i)
            return
        } catch (e: Exception) {
        }
        try {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            toast("اختر «استوديو الثيمات» من قائمة الخلفيات الحية")
            return
        } catch (e: Exception) {
        }
        toast("تعذر فتح شاشة الخلفية الحية. افتح: الإعدادات ← الخلفية ← الخلفيات الحية، ثم اختر «استوديو الثيمات».")
    }

    // ------------------------------------------------------------------

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_PHOTO -> {
                val uri = data.data
                if (uri != null) importPhoto(uri)
            }
            REQ_FONT -> importFonts(data)
        }
    }

    companion object {
        private const val REQ_PHOTO = 1
        private const val REQ_FONT = 2
    }
}
