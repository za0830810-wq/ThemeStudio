package com.themestudio.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** كل إعدادات التطبيق. تُخزَّن محلياً ولا تحتاج إنترنت. */
class Prefs(context: Context) {

    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("theme_studio", Context.MODE_PRIVATE)

    var themeIndex: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    /** 0 = سطر واحد، 1 = سطران عموديان */
    var clockStyle: Int
        get() = sp.getInt("style", 0)
        set(v) { sp.edit().putInt("style", v).apply() }

    var clockColor: Int
        get() = sp.getInt("color", Color.WHITE)
        set(v) { sp.edit().putInt("color", v).apply() }

    /** 30..255 */
    var clockOpacity: Int
        get() = sp.getInt("opacity", 235)
        set(v) { sp.edit().putInt("opacity", v).apply() }

    /** عرض الساعة كنسبة من عرض الشاشة 20..100 */
    var clockSizePct: Int
        get() = sp.getInt("size", 80)
        set(v) { sp.edit().putInt("size", v).apply() }

    /** الموضع العمودي 0..100 */
    var clockYPct: Int
        get() = sp.getInt("ypos", 28)
        set(v) { sp.edit().putInt("ypos", v).apply() }

    var use24h: Boolean
        get() = sp.getBoolean("h24", true)
        set(v) { sp.edit().putBoolean("h24", v).apply() }

    var arabicDigits: Boolean
        get() = sp.getBoolean("arabic", false)
        set(v) { sp.edit().putBoolean("arabic", v).apply() }

    var showDate: Boolean
        get() = sp.getBoolean("date", true)
        set(v) { sp.edit().putBoolean("date", v).apply() }

    var fade: Boolean
        get() = sp.getBoolean("fade", true)
        set(v) { sp.edit().putBoolean("fade", v).apply() }

    /** الساعة خلف الشكل في الصورة */
    var depth: Boolean
        get() = sp.getBoolean("depth", true)
        set(v) { sp.edit().putBoolean("depth", v).apply() }

    /** اسم ملف الخط المستورد، فارغ = الخط الافتراضي */
    var fontName: String
        get() = sp.getString("font", "") ?: ""
        set(v) { sp.edit().putString("font", v).apply() }

    /** يُستدعى بعد تغيير ملفات الصورة أو الخطوط ليعيد الخلفية الحية تحميلها */
    fun touch() {
        sp.edit().putLong("rev", System.nanoTime()).apply()
    }

    companion object {
        /** المفاتيح التي تستلزم إعادة تحميل الصور والخطوط */
        val ASSET_KEYS: Set<String> = setOf("theme", "depth", "font", "rev")
    }
}
