package com.themestudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object ImageImport {

    @Suppress("DEPRECATION")
    fun screenSize(ctx: Context): Pair<Int, Int> {
        val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val w: Int
        val h: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            w = dm.widthPixels
            h = dm.heightPixels
        }
        var lo = max(1, min(w, h))
        var hi = max(1, max(w, h))
        if (hi > 2560) {
            val s = 2560f / hi
            lo = max(1, (lo * s).toInt())
            hi = 2560
        }
        return Pair(lo, hi)
    }

    /** يقرأ الصورة، يقصها لتناسب شاشة الهاتف تماماً، ويحفظها. يعيد true عند النجاح. */
    fun importPhoto(ctx: Context, uri: Uri): Boolean {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

        val (sw, sh) = screenSize(ctx)

        var sample = 1
        while (min(bounds.outWidth, bounds.outHeight) / (sample * 2) >= sw &&
            max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= sh
        ) {
            sample *= 2
        }

        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false

        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Throwable) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                m.postRotate(90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                m.postRotate(270f)
                m.postScale(-1f, 1f)
            }
        }
        if (!m.isIdentity) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }

        // قص بحجم الشاشة (cover)
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val s = max(sw / bmp.width.toFloat(), sh / bmp.height.toFloat())
        val dw = bmp.width * s
        val dh = bmp.height * s
        val dstM = Matrix()
        dstM.postScale(s, s)
        dstM.postTranslate((sw - dw) / 2f, (sh - dh) / 2f)
        canvas.drawBitmap(bmp, dstM, Paint(Paint.FILTER_BITMAP_FLAG))

        val bgFile = AssetLoader.bgFile(ctx)
        val tmp = File(bgFile.parentFile, "bg.tmp")
        FileOutputStream(tmp).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        if (!tmp.renameTo(bgFile)) {
            bgFile.delete()
            if (!tmp.renameTo(bgFile)) return false
        }
        AssetLoader.fgFile(ctx).delete()
        return true
    }
}
