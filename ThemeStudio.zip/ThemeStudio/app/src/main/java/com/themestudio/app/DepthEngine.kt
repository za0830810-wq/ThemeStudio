package com.themestudio.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * ذكاء اصطناعي يعمل داخل الهاتف (نموذج U²-Net الصغير داخل التطبيق نفسه).
 * يفصل الشكل الرئيسي في الصورة عن الخلفية حتى تظهر الساعة خلفه. لا يحتاج إنترنت.
 */
object DepthEngine {
    private const val SIZE = 320

    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null

    @Synchronized
    private fun ensureSession(ctx: Context): Pair<OrtEnvironment, OrtSession> {
        val e0 = env
        val s0 = session
        if (e0 != null && s0 != null) return Pair(e0, s0)
        val e = OrtEnvironment.getEnvironment()
        val bytes = ctx.applicationContext.assets.open("u2netp.onnx").use { it.readBytes() }
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(2)
        val s = e.createSession(bytes, opts)
        env = e
        session = s
        return Pair(e, s)
    }

    /** يعيد نسخة من الصورة قناة الشفافية فيها = الشكل الرئيسي فقط. */
    fun cutout(ctx: Context, src: Bitmap): Bitmap {
        val (e, s) = ensureSession(ctx)
        val n = SIZE * SIZE

        val small = Bitmap.createScaledBitmap(src, SIZE, SIZE, true)
        val px = IntArray(n)
        small.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
        if (small !== src) small.recycle()

        val r = FloatArray(n)
        val g = FloatArray(n)
        val b = FloatArray(n)
        var mx = 1e-6f
        for (i in 0 until n) {
            val c = px[i]
            r[i] = ((c shr 16) and 0xFF) / 255f
            g[i] = ((c shr 8) and 0xFF) / 255f
            b[i] = (c and 0xFF) / 255f
            mx = max(mx, max(r[i], max(g[i], b[i])))
        }

        val buf = ByteBuffer.allocateDirect(4 * 3 * n).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until n) buf.put((r[i] / mx - 0.485f) / 0.229f)
        for (i in 0 until n) buf.put((g[i] / mx - 0.456f) / 0.224f)
        for (i in 0 until n) buf.put((b[i] / mx - 0.406f) / 0.225f)
        buf.rewind()

        val mask = FloatArray(n)
        val tensor = OnnxTensor.createTensor(e, buf, longArrayOf(1L, 3L, SIZE.toLong(), SIZE.toLong()))
        try {
            val inputName = s.inputNames.iterator().next()
            val result = s.run(mapOf(inputName to tensor))
            try {
                @Suppress("UNCHECKED_CAST")
                val out = result.get(0).value as Array<Array<Array<FloatArray>>>
                val plane = out[0][0]
                for (y in 0 until SIZE) System.arraycopy(plane[y], 0, mask, y * SIZE, SIZE)
            } finally {
                result.close()
            }
        } finally {
            tensor.close()
        }

        // تطبيع القيم ثم زيادة حدة الحواف
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (v in mask) {
            if (v < lo) lo = v
            if (v > hi) hi = v
        }
        val range = max(hi - lo, 1e-6f)
        var sum = 0.0
        for (i in 0 until n) {
            val t = (((mask[i] - lo) / range) - 0.2f) / 0.6f
            val tc = if (t < 0f) 0f else if (t > 1f) 1f else t
            val m = tc * tc * (3f - 2f * tc)
            mask[i] = m
            sum += m
        }
        val coverage = sum / n
        if (coverage < 0.01) throw IllegalStateException("لم أجد شكلاً واضحاً في هذه الصورة")
        if (coverage > 0.93) throw IllegalStateException("الصورة كلها شكل واحد، لا توجد خلفية لفصلها")

        // تكبير القناع إلى حجم الصورة بنعومة
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val wx = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x + 0.5f) * SIZE / w - 0.5f
            val i0 = floor(fx).toInt().coerceIn(0, SIZE - 1)
            x0[x] = i0
            x1[x] = min(i0 + 1, SIZE - 1)
            wx[x] = (fx - i0).coerceIn(0f, 1f)
        }
        for (y in 0 until h) {
            val fy = (y + 0.5f) * SIZE / h - 0.5f
            val y0 = floor(fy).toInt().coerceIn(0, SIZE - 1)
            val y1 = min(y0 + 1, SIZE - 1)
            val wy = (fy - y0).coerceIn(0f, 1f)
            val row0 = y0 * SIZE
            val row1 = y1 * SIZE
            val base = y * w
            for (x in 0 until w) {
                val a = x0[x]
                val c = x1[x]
                val t = wx[x]
                val top = mask[row0 + a] * (1f - t) + mask[row0 + c] * t
                val bot = mask[row1 + a] * (1f - t) + mask[row1 + c] * t
                val m = top * (1f - wy) + bot * wy
                val alpha = (m * 255f + 0.5f).toInt().coerceIn(0, 255)
                pixels[base + x] = (alpha shl 24) or (pixels[base + x] and 0x00FFFFFF)
            }
        }

        val outBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        outBmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return outBmp
    }
}
