package com.themestudio.app

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Inflater

class FontImportResult(val name: String?, val error: String?)

/**
 * مخزن الخطوط: يستورد TTF و OTF و TTC و OTC و WOFF.
 * (WOFF2 غير مدعومة في أندرويد، فنعرض رسالة واضحة.)
 * يتعرف على نوع الملف من محتواه لا من امتداده.
 */
object FontStore {
    private const val MAX_BYTES = 40L * 1024L * 1024L

    fun dir(ctx: Context): File {
        val d = File(ctx.applicationContext.filesDir, "fonts")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun list(ctx: Context): List<String> {
        val files = dir(ctx).listFiles() ?: return emptyList()
        return files.filter { it.isFile }.map { it.name }.sorted()
    }

    fun defaultTypeface(): Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

    fun load(ctx: Context, name: String): Typeface {
        if (name.isEmpty()) return defaultTypeface()
        return try {
            val f = File(dir(ctx), name)
            if (f.exists()) (Typeface.Builder(f).build() ?: defaultTypeface()) else defaultTypeface()
        } catch (e: Throwable) {
            defaultTypeface()
        }
    }

    fun delete(ctx: Context, name: String) {
        try {
            File(dir(ctx), name).delete()
        } catch (e: Throwable) {
        }
    }

    fun importFont(ctx: Context, uri: Uri): FontImportResult {
        try {
            val displayName = queryName(ctx, uri) ?: "font"
            val bytes = readLimited(ctx, uri) ?: return FontImportResult(null, "الملف كبير جداً: $displayName")
            val kind = detect(bytes) ?: return FontImportResult(null, "ليس خطاً مدعوماً: $displayName")
            if (kind == "woff2") {
                return FontImportResult(
                    null,
                    "صيغة WOFF2 غير مدعومة في أندرويد. حوّل الملف إلى TTF أو OTF ثم أضفه: $displayName"
                )
            }
            var data = bytes
            var ext = kind
            if (kind == "woff") {
                data = Woff.toSfnt(bytes) ?: return FontImportResult(null, "تعذر قراءة ملف WOFF: $displayName")
                ext = if (data.size >= 4 && String(data, 0, 4, Charsets.ISO_8859_1) == "OTTO") "otf" else "ttf"
            }
            val base = sanitize(displayName.substringBeforeLast('.', displayName))
            val out = File(dir(ctx), "$base.$ext")
            out.writeBytes(data)
            val tf = try {
                Typeface.Builder(out).build()
            } catch (e: Throwable) {
                null
            }
            if (tf == null) {
                out.delete()
                return FontImportResult(null, "الملف تالف أو غير صالح كخط: $displayName")
            }
            return FontImportResult(out.name, null)
        } catch (e: Throwable) {
            return FontImportResult(null, "تعذر استيراد الخط")
        }
    }

    private fun detect(b: ByteArray): String? {
        if (b.size < 12) return null
        val tag = String(b, 0, 4, Charsets.ISO_8859_1)
        if (b[0] == 0.toByte() && b[1] == 1.toByte() && b[2] == 0.toByte() && b[3] == 0.toByte()) return "ttf"
        return when (tag) {
            "true" -> "ttf"
            "OTTO" -> "otf"
            "ttcf" -> "ttc"
            "wOFF" -> "woff"
            "wOF2" -> "woff2"
            else -> null
        }
    }

    private fun sanitize(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (Character.isLetterOrDigit(ch) || ch == '-' || ch == '_') sb.append(ch) else sb.append('_')
        }
        var r = sb.toString().trim('_')
        if (r.isEmpty()) r = "font"
        if (r.length > 60) r = r.substring(0, 60)
        return r
    }

    private fun queryName(ctx: Context, uri: Uri): String? {
        return try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun readLimited(ctx: Context, uri: Uri): ByteArray? {
        val ins = ctx.contentResolver.openInputStream(uri) ?: return null
        val bos = ByteArrayOutputStream()
        try {
            val buf = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_BYTES) return null
                bos.write(buf, 0, n)
            }
        } finally {
            ins.close()
        }
        return bos.toByteArray()
    }
}

/** تحويل WOFF 1.0 إلى ملف خط عادي (sfnt) يفهمه أندرويد. */
object Woff {
    private class Entry(val tag: Int, val off: Int, val comp: Int, val orig: Int, val sum: Int)

    fun toSfnt(w: ByteArray): ByteArray? {
        if (w.size < 44) return null
        val bb = ByteBuffer.wrap(w).order(ByteOrder.BIG_ENDIAN)
        val flavor = bb.getInt(4)
        val n = bb.getShort(12).toInt() and 0xFFFF
        if (n == 0 || 44 + n * 20 > w.size) return null

        val entries = ArrayList<Entry>()
        var total = 12 + 16 * n
        for (i in 0 until n) {
            val b = 44 + i * 20
            val e = Entry(bb.getInt(b), bb.getInt(b + 4), bb.getInt(b + 8), bb.getInt(b + 12), bb.getInt(b + 16))
            if (e.off < 0 || e.comp < 0 || e.orig < 0 || e.orig > 64 * 1024 * 1024) return null
            if (e.off.toLong() + e.comp.toLong() > w.size.toLong()) return null
            entries.add(e)
            total += (e.orig + 3) and 3.inv()
        }

        val out = ByteArray(total)
        val ob = ByteBuffer.wrap(out).order(ByteOrder.BIG_ENDIAN)
        ob.putInt(0, flavor)
        ob.putShort(4, n.toShort())
        var pow = 1
        var log = 0
        while (pow * 2 <= n) {
            pow *= 2
            log++
        }
        ob.putShort(6, (pow * 16).toShort())
        ob.putShort(8, log.toShort())
        ob.putShort(10, (n * 16 - pow * 16).toShort())

        var pos = 12 + 16 * n
        for ((i, e) in entries.withIndex()) {
            val d = 12 + 16 * i
            ob.putInt(d, e.tag)
            ob.putInt(d + 4, e.sum)
            ob.putInt(d + 8, pos)
            ob.putInt(d + 12, e.orig)
            if (e.comp == e.orig) {
                System.arraycopy(w, e.off, out, pos, e.orig)
            } else {
                val inf = Inflater()
                try {
                    inf.setInput(w, e.off, e.comp)
                    var got = 0
                    while (got < e.orig) {
                        val r = inf.inflate(out, pos + got, e.orig - got)
                        if (r <= 0) break
                        got += r
                    }
                    if (got != e.orig) return null
                } finally {
                    inf.end()
                }
            }
            pos += (e.orig + 3) and 3.inv()
        }
        return out
    }
}
