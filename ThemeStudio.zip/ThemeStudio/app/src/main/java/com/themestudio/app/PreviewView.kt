package com.themestudio.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider

/** معاينة حية للشاشة داخل التطبيق، ترسم بنفس الكود المستخدم في الخلفية الحية. */
class PreviewView(ctx: Context, private val prefs: Prefs) : View(ctx) {

    private var assets: RenderAssets? = null

    private val ticker = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, if (Renderer.isAnimated(prefs)) 40L else 1000L)
        }
    }

    init {
        val radius = 22f * resources.displayMetrics.density
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
    }

    /** بعد تغيير الثيم أو الصورة أو الخط */
    fun reload() {
        assets = AssetLoader.load(context, prefs)
        removeCallbacks(ticker)
        post(ticker)
    }

    /** بعد تغيير أي إعداد لا يحتاج تحميل ملفات */
    fun refresh() {
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        reload()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val a = assets ?: return
        Renderer.draw(canvas, width, height, prefs, a, System.currentTimeMillis())
    }
}
