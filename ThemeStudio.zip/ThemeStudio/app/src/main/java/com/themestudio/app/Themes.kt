package com.themestudio.app

class ThemeDef(
    val name: String,
    val kind: Int,
    val c1: Int,
    val c2: Int,
    val c3: Int
)

object Themes {
    const val KIND_GRADIENT = 0
    const val KIND_AURORA = 1
    const val KIND_STARS = 2
    const val KIND_PHOTO = 3

    val all: List<ThemeDef> = listOf(
        ThemeDef("غروب", KIND_GRADIENT, 0xFFFF9966.toInt(), 0xFFB5446E.toInt(), 0xFF3A1C71.toInt()),
        ThemeDef("محيط", KIND_GRADIENT, 0xFF2C5364.toInt(), 0xFF203A43.toInt(), 0xFF0F2027.toInt()),
        ThemeDef("ليل", KIND_GRADIENT, 0xFF2B2E33.toInt(), 0xFF111418.toInt(), 0xFF000000.toInt()),
        ThemeDef("زمرد", KIND_GRADIENT, 0xFF11998E.toInt(), 0xFF0B6B63.toInt(), 0xFF053B3A.toInt()),
        ThemeDef("شفق متحرك", KIND_AURORA, 0xFF00E5A0.toInt(), 0xFF7C4DFF.toInt(), 0xFF29B6F6.toInt()),
        ThemeDef("نجوم متحركة", KIND_STARS, 0xFF1A1F4B.toInt(), 0xFF0B1026.toInt(), 0xFF020308.toInt()),
        ThemeDef("صورتي", KIND_PHOTO, 0xFF2C3E50.toInt(), 0xFF1B2735.toInt(), 0xFF090A0F.toInt())
    )

    val photoIndex: Int
        get() = all.size - 1
}
