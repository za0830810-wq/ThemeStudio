package com.themestudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class RenderAssets(val bg: Bitmap?, val fg: Bitmap?, val typeface: Typeface) {
    fun recycle() {
        try {
            bg?.recycle()
            fg?.recycle()
        } catch (e: Throwable) {
        }
    }
}

object AssetLoader {
    fun bgFile(ctx: Context): File = File(ctx.applicationContext.filesDir, "bg.jpg")
    fun fgFile(ctx: Context): File = File(ctx.applicationContext.filesDir, "fg.png")

    fun load(ctx: Context, prefs: Prefs): RenderAssets {
        val theme = Themes.all.getOrElse(prefs.themeIndex) { Themes.all[0] }
        var bg: Bitmap? = null
        var fg: Bitmap? = null
        if (theme.kind == Themes.KIND_PHOTO) {
            bg = decodeOrNull(bgFile(ctx))
            if (bg != null && prefs.depth) fg = decodeOrNull(fgFile(ctx))
        }
        return RenderAssets(bg, fg, FontStore.load(ctx, prefs.fontName))
    }

    private fun decodeOrNull(f: File): Bitmap? {
        return try {
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        } catch (e: Throwable) {
            null
        }
    }
}

/** يرسم الخلفية ثم الساعة ثم (اختيارياً) الشكل الأمامي فوق الساعة. تُستخدم في المعاينة وفي الخلفية الحية. */
object Renderer {
    private const val GAP = 1.16f
    private const val TWO_PI = 6.2831855f
    private const val LOOP_MS = 600_000L

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()
    private val bounds = Rect()

    private val dateFmt: SimpleDateFormat by lazy { SimpleDateFormat("EEEE d MMMM", Locale("ar")) }

    // كل نجمة: x, y, الحجم, الطور, السرعة
    private val starData: FloatArray = run {
        val r = Random(7L)
        FloatArray(110 * 5) { r.nextFloat() }
    }

    fun isAnimated(p: Prefs): Boolean {
        val k = Themes.all.getOrNull(p.themeIndex)?.kind
        return k == Themes.KIND_AURORA || k == Themes.KIND_STARS
    }

    fun draw(c: Canvas, w: Int, h: Int, p: Prefs, a: RenderAssets, now: Long) {
        if (w <= 0 || h <= 0) return
        val theme = Themes.all.getOrElse(p.themeIndex) { Themes.all[0] }
        drawBackground(c, w, h, theme, a.bg, now)
        drawClock(c, w, h, p, a.typeface, now)
        val fg = a.fg
        if (fg != null && p.depth && theme.kind == Themes.KIND_PHOTO) {
            drawCover(c, fg, w, h)
        }
    }

    // ---------------- الخلفية ----------------

    private fun drawBackground(c: Canvas, w: Int, h: Int, t: ThemeDef, bg: Bitmap?, now: Long) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        when (t.kind) {
            Themes.KIND_PHOTO -> {
                if (bg != null) drawCover(c, bg, w, h) else gradient(c, wf, hf, t.c1, t.c2, t.c3)
            }
            Themes.KIND_AURORA -> {
                gradient(c, wf, hf, 0xFF0B1026.toInt(), 0xFF0A0D20.toInt(), 0xFF050816.toInt())
                aurora(c, wf, hf, t, now)
            }
            Themes.KIND_STARS -> {
                gradient(c, wf, hf, t.c1, t.c2, t.c3)
                stars(c, wf, hf, now)
            }
            else -> gradient(c, wf, hf, t.c1, t.c2, t.c3)
        }
    }

    private fun gradient(c: Canvas, w: Float, h: Float, c1: Int, c2: Int, c3: Int) {
        fillPaint.color = Color.BLACK // يعيد الشفافية الكاملة بعد رسم النجوم
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(c1, c2, c3),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, fillPaint)
        fillPaint.shader = null
    }

    private fun withAlpha(col: Int, a: Int): Int = (col and 0x00FFFFFF) or (a shl 24)

    private fun aurora(c: Canvas, w: Float, h: Float, t: ThemeDef, now: Long) {
        // الحركة تتكرر كل 10 دقائق بدورات كاملة، فلا توجد قفزات
        val ph = (now % LOOP_MS) / LOOP_MS.toFloat()
        val cols = intArrayOf(t.c1, t.c2, t.c3)
        val r = max(w, h) * 0.6f
        fillPaint.color = Color.BLACK
        for (i in 0..2) {
            val cx = w * (0.5f + 0.38f * sin(TWO_PI * 29f * ph + i * 2.1f))
            val cy = h * (0.5f + 0.32f * cos(TWO_PI * 22f * ph + i * 1.7f))
            fillPaint.shader = RadialGradient(
                cx, cy, r,
                withAlpha(cols[i], 150), withAlpha(cols[i], 0),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, fillPaint)
        }
        fillPaint.shader = null
    }

    private fun stars(c: Canvas, w: Float, h: Float, now: Long) {
        val ph = (now % LOOP_MS) / LOOP_MS.toFloat()
        val unit = w / 360f
        val n = starData.size / 5
        for (i in 0 until n) {
            val b = i * 5
            val x = starData[b] * w
            val wraps = 1 + (starData[b + 4] * 4f).toInt()
            val y = (starData[b + 1] + wraps * ph) % 1f
            val cycles = 76 + (starData[b + 4] * 144f).toInt()
            val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(TWO_PI * cycles * ph + starData[b + 3] * TWO_PI))
            val alpha = (tw * 255f).toInt().coerceIn(0, 255)
            fillPaint.color = Color.argb(alpha, 255, 255, 255)
            c.drawCircle(x, y * h, (0.6f + starData[b + 2] * 1.8f) * unit, fillPaint)
        }
    }

    private fun drawCover(c: Canvas, bmp: Bitmap, w: Int, h: Int) {
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        if (bw <= 0f || bh <= 0f) return
        val s = max(w / bw, h / bh)
        val sw = bw * s
        val sh = bh * s
        val l = (w - sw) / 2f
        val t = (h - sh) / 2f
        dst.set(l, t, l + sw, t + sh)
        c.drawBitmap(bmp, null, dst, bgPaint)
    }

    // ---------------- الساعة ----------------

    private fun two(n: Int): String = if (n < 10) "0$n" else "$n"

    private fun convertDigits(s: String, toArabic: Boolean): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (toArabic && ch in '0'..'9') {
                sb.append((0x0660 + (ch - '0')).toChar())
            } else if (!toArabic && ch in '٠'..'٩') {
                sb.append(('0'.code + (ch - '٠')).toChar())
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun clockLines(p: Prefs, now: Long): List<String> {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        var hh = cal.get(if (p.use24h) Calendar.HOUR_OF_DAY else Calendar.HOUR)
        if (!p.use24h && hh == 0) hh = 12
        val mm = cal.get(Calendar.MINUTE)
        val hs = two(hh)
        val ms = two(mm)
        val lines = if (p.clockStyle == 1) listOf(hs, ms) else listOf("$hs:$ms")
        return lines.map { convertDigits(it, p.arabicDigits) }
    }

    private fun capHeight(sample: String, size: Float): Float {
        textPaint.textSize = size
        textPaint.getTextBounds(sample, 0, sample.length, bounds)
        val h = bounds.height().toFloat()
        return if (h > 0f) h else size * 0.7f
    }

    private fun drawClock(c: Canvas, w: Int, h: Int, p: Prefs, tf: Typeface, now: Long) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val lines = clockLines(p, now)

        textPaint.typeface = tf
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.shader = null
        textPaint.textSize = 100f

        // مقاييس ثابتة لا تتغير بتغير الدقيقة: أعرض رقم في الخط، ونص مرجعي لارتفاع الأرقام
        val digits = convertDigits("0123456789", p.arabicDigits)
        var widest = 0f
        for (ch in digits) widest = max(widest, textPaint.measureText(ch.toString()))
        val maxW = if (p.clockStyle == 1) {
            widest * 2f
        } else {
            widest * 4f + textPaint.measureText(":")
        }
        if (maxW <= 0f) return

        var size = 100f * (wf * p.clockSizePct / 100f) / maxW
        val sample = digits
        var capH = capHeight(sample, size)
        var blockH = capH + (lines.size - 1) * capH * GAP
        val maxH = hf * 0.62f
        if (blockH > maxH) {
            size *= maxH / blockH
            capH = capHeight(sample, size)
            blockH = capH + (lines.size - 1) * capH * GAP
        }
        textPaint.textSize = size

        val centerY = hf * p.clockYPct / 100f
        val top = (centerY - blockH / 2f).coerceIn(0f, max(0f, hf - blockH))

        val rgb = p.clockColor and 0x00FFFFFF
        val opacity = p.clockOpacity.coerceIn(0, 255)
        val baseColor = rgb or (opacity shl 24)
        if (p.fade) {
            val bottom = rgb or ((opacity * 0.45f).toInt().coerceIn(0, 255) shl 24)
            textPaint.shader = LinearGradient(0f, top, 0f, top + blockH, baseColor, bottom, Shader.TileMode.CLAMP)
            textPaint.color = Color.WHITE
        } else {
            textPaint.shader = null
            textPaint.color = baseColor
        }
        for ((i, l) in lines.withIndex()) {
            val baseline = top + capH + i * capH * GAP
            c.drawText(l, wf / 2f, baseline, textPaint)
        }
        textPaint.shader = null

        if (p.showDate) {
            val ds = wf * 0.05f
            textPaint.textSize = ds
            textPaint.color = rgb or ((opacity * 0.85f).toInt().coerceIn(0, 255) shl 24)
            val text = convertDigits(dateFmt.format(Date(now)), p.arabicDigits)
            val y = min(top + blockH + ds * 2f, hf - ds)
            c.drawText(text, wf / 2f, y, textPaint)
        }
    }
}
