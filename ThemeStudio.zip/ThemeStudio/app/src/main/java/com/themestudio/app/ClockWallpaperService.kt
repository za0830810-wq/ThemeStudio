package com.themestudio.app

import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/**
 * الخلفية الحية: ترسم الثيم والساعة (والشكل الأمامي فوقها) على الشاشة الرئيسية والقفل.
 * لا تحتاج إنترنت ولا أي صلاحيات.
 */
class ClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {

        private val handler = Handler(Looper.getMainLooper())
        private val prefs = Prefs(this@ClockWallpaperService)
        private var assets: RenderAssets? = null
        private var isShown = false
        private var surfaceW = 0
        private var surfaceH = 0
        private val frame = Runnable { drawFrame() }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.sp.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
            handler.removeCallbacks(frame)
            assets = null
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceW = width
            surfaceH = height
            reload()
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            isShown = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            isShown = visible
            if (visible) {
                drawFrame()
            } else {
                handler.removeCallbacks(frame)
            }
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            if (key == null || key in Prefs.ASSET_KEYS) reload()
            drawFrame()
        }

        private fun reload() {
            if (surfaceW <= 0 || surfaceH <= 0) return
            assets = AssetLoader.load(applicationContext, prefs)
        }

        private fun drawFrame() {
            handler.removeCallbacks(frame)
            if (surfaceW <= 0 || surfaceH <= 0) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                val a = assets
                if (canvas != null && a != null) {
                    Renderer.draw(canvas, surfaceW, surfaceH, prefs, a, System.currentTimeMillis())
                }
            } catch (e: Throwable) {
                // نتجاهل أي خطأ رسم ولا نُسقط الخلفية
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Throwable) {
                    }
                }
            }
            if (isShown) {
                val now = System.currentTimeMillis()
                val delay = if (Renderer.isAnimated(prefs)) 33L else 60_000L - (now % 60_000L) + 30L
                handler.postDelayed(frame, delay)
            }
        }
    }
}
